package com.ejemplo.dbsrf.Controller;

import java.util.ArrayList;
import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;

import com.ejemplo.dbsrf.Dao.TurnosDao;
import com.ejemplo.dbsrf.Models.Dias;
import com.ejemplo.dbsrf.Models.Turnos;
import com.ejemplo.dbsrf.Service.TurnosServiceImpl;
import com.google.gson.Gson;

@RestController
@RequestMapping(path="/turnos")
@CrossOrigin(origins = {"http://192.168.43.168:4200","http://localhost:8100" ,"http://localhost:4200" , "http://localhost:8082","http://localhost:8080","http://127.0.0.1:8080","http://127.0.0.1:4200"})
public class TurnosCtrl {

	@Autowired
	private TurnosServiceImpl turnosService;
	private TurnosDao turnosdao;
	Gson gson = new Gson();
	
	String jsont;
	
	@RequestMapping(method=RequestMethod.GET,
			path="/getturnos"
			)
	public List<Turnos> getAll(){
		return turnosService.getAll();
	}

	
	@RequestMapping(method=RequestMethod.GET,
			path="/getturnoas"
			)
	public List<Turnos> getsAll(){
		 return turnosService.getAll();
	}
	
	@RequestMapping(method=RequestMethod.GET,
			path="/getturno/{id}"
			)
	public Turnos getTurno(@PathVariable(value = "id") int id) {
		return turnosService.get(id);
	}
	@RequestMapping(method=RequestMethod.POST,produces = MediaType.ALL_VALUE, consumes = MediaType.ALL_VALUE,
			path="/turno")
	@ResponseBody
	public void add(@RequestBody String Turn) {
		String[] data = Turn.split("|",2);
		Turnos t=gson.fromJson(data[1].replace("|",""),Turnos.class);
		int a=Integer.parseInt(data[0]);
		Dias d=new Dias(a);
		t.setDias(d);
		turnosService.post(t);
	}
	@RequestMapping(method=RequestMethod.POST,produces = MediaType.ALL_VALUE, consumes = MediaType.ALL_VALUE,
			path="/turnoe")
	@ResponseBody
	public void update(@RequestBody String t) {
		String[] data = t.split("|",5);
		Turnos tu=gson.fromJson(data[4].replace("|",""),Turnos.class);
		turnosService.put(tu, Integer.parseInt(data[2]));
	}
	
	@RequestMapping(method=RequestMethod.POST,produces = MediaType.ALL_VALUE, consumes = MediaType.ALL_VALUE,
			path="/turnod")
	@ResponseBody
	public void delete(@RequestBody String id) {
		turnosService.delete(Integer.parseInt(id));
	}
	
	
}
