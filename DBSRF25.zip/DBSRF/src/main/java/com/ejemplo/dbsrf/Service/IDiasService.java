package com.ejemplo.dbsrf.Service;

import java.util.List;

import com.ejemplo.dbsrf.Models.Dias;

public interface IDiasService {
	public Dias get(Integer id);
	public List<Dias> getAll();
	
}
