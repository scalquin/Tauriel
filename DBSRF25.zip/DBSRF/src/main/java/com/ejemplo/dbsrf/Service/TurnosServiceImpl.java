package com.ejemplo.dbsrf.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;

import com.ejemplo.dbsrf.Models.Turnos;
import com.ejemplo.dbsrf.Dao.TurnosDao;



@Service
public class TurnosServiceImpl implements ITurnosService{
	
	@Autowired
	private TurnosDao turnosDao;
	
	@Override
	public Turnos get(int id) {
		return turnosDao.findById(id).get();
	}
	
	@Override
	public List<Turnos> getAll(){
		return turnosDao.findAll();
	}

	@Override
	public void post(Turnos t) {
		turnosDao.save(t);
		
	}

	@Override
	public void put(Turnos t, int id) {
		turnosDao.findById(id).ifPresent((x)->{
			t.setTur_cod(id);
			turnosDao.save(t);
		});
	}

	@Override
	public void delete(Integer id) {
		turnosDao.deleteById(id);
	}

	
}
