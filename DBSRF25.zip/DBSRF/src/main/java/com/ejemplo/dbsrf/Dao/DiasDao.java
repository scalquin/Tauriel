package com.ejemplo.dbsrf.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ejemplo.dbsrf.Models.Dias;

public interface DiasDao extends JpaRepository<Dias, Integer> {
	
}
