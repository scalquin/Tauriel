package com.ejemplo.dbsrf.Models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.sun.istack.Nullable;

@Entity
@Table(name="asistencia")
public class Asistencia implements Serializable{

	private static final long serialVersionUID = 1L;
		
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="asi_cod")
	private Integer asi_cod;
	
	@Column(name="asi_horaIni")
	private String asi_horaIni;
	
	@Column(name="asi_horaFin")
	private String asi_horaFin;
	
	@Column(name="asi_fecha")
	private String asi_fecha;
	
	@Column(name="asi_ver")
	private boolean asi_ver;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name= "hor_cod")
	@Nullable
	private Horarios horarios;

	public Asistencia() {
	}

	public Asistencia(Integer asi_cod, String asi_horaIni, String asi_horaFin, String asi_fecha, boolean asi_ver,
			Horarios horarios) {
		super();
		this.asi_cod = asi_cod;
		this.asi_horaIni = asi_horaIni;
		this.asi_horaFin = asi_horaFin;
		this.asi_fecha = asi_fecha;
		this.asi_ver = asi_ver;
		this.horarios = horarios;
	}

	public Integer getAsi_cod() {
		return asi_cod;
	}

	public void setAsi_cod(Integer asi_cod) {
		this.asi_cod = asi_cod;
	}

	public String getAsi_horaIni() {
		return asi_horaIni;
	}

	public void setAsi_horaIni(String asi_horaIni) {
		this.asi_horaIni = asi_horaIni;
	}

	public String getAsi_horaFin() {
		return asi_horaFin;
	}

	public void setAsi_horaFin(String asi_horaFin) {
		this.asi_horaFin = asi_horaFin;
	}

	public String getAsi_fecha() {
		return asi_fecha;
	}

	public void setAsi_fecha(String asi_fecha) {
		this.asi_fecha = asi_fecha;
	}

	public boolean isAsi_ver() {
		return asi_ver;
	}

	public void setAsi_ver(boolean asi_ver) {
		this.asi_ver = asi_ver;
	}

	public Horarios getHorarios() {
		return horarios;
	}

	public void setHorarios(Horarios horarios) {
		this.horarios = horarios;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((asi_cod == null) ? 0 : asi_cod.hashCode());
		result = prime * result + ((asi_fecha == null) ? 0 : asi_fecha.hashCode());
		result = prime * result + ((asi_horaFin == null) ? 0 : asi_horaFin.hashCode());
		result = prime * result + ((asi_horaIni == null) ? 0 : asi_horaIni.hashCode());
		result = prime * result + (asi_ver ? 1231 : 1237);
		result = prime * result + ((horarios == null) ? 0 : horarios.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Asistencia other = (Asistencia) obj;
		if (asi_cod == null) {
			if (other.asi_cod != null)
				return false;
		} else if (!asi_cod.equals(other.asi_cod))
			return false;
		if (asi_fecha == null) {
			if (other.asi_fecha != null)
				return false;
		} else if (!asi_fecha.equals(other.asi_fecha))
			return false;
		if (asi_horaFin == null) {
			if (other.asi_horaFin != null)
				return false;
		} else if (!asi_horaFin.equals(other.asi_horaFin))
			return false;
		if (asi_horaIni == null) {
			if (other.asi_horaIni != null)
				return false;
		} else if (!asi_horaIni.equals(other.asi_horaIni))
			return false;
		if (asi_ver != other.asi_ver)
			return false;
		if (horarios == null) {
			if (other.horarios != null)
				return false;
		} else if (!horarios.equals(other.horarios))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Asistencia [asi_cod=" + asi_cod + ", asi_horaIni=" + asi_horaIni + ", asi_horaFin=" + asi_horaFin
				+ ", asi_fecha=" + asi_fecha + ", asi_ver=" + asi_ver + ", horarios=" + horarios + "]";
	}
	
	
}
