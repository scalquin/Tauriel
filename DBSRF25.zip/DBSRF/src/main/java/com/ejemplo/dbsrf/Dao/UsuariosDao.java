package com.ejemplo.dbsrf.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ejemplo.dbsrf.Models.Usuarios;

public interface UsuariosDao extends JpaRepository<Usuarios, Integer> {
	//Usuario findByNombre(String nombre);
}
