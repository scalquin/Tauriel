package com.ejemplo.dbsrf.Models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="alert")
public class alertas implements Serializable{
	

		private static final long serialVersionUID = 1L;
		
		@Id
	    @GeneratedValue(strategy = GenerationType.IDENTITY)
		@Column(name="ale_cod")
		private Integer ale_cod;
			
		@Column(name="ale_fechor")
		private String ale_fechor;

		public alertas() {
		}

		public alertas(Integer ale_cod, String ale_fechor) {
			super();
			this.ale_cod = ale_cod;
			this.ale_fechor = ale_fechor;
		}

		public Integer getAle_cod() {
			return ale_cod;
		}

		public void setAle_cod(Integer ale_cod) {
			this.ale_cod = ale_cod;
		}

		public String getAle_fechor() {
			return ale_fechor;
		}

		public void setAle_fechor(String ale_fechor) {
			this.ale_fechor = ale_fechor;
		}
		
		
}
