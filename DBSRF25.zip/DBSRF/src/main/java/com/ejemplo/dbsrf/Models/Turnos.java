package com.ejemplo.dbsrf.Models;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.sun.istack.Nullable;



@Entity
@Table(name="turnos")
public class Turnos implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="tur_cod")
	private Integer tur_cod;
	
	@Column(name="tur_ini")
	private String tur_ini;
	
	@Column(name="tur_fin")
	private String tur_fin;
	
	@Column(name="tur_fecha")
	private String tur_fecha;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name= "dia_cod")
	@Nullable
	private Dias dias;
	
	public Turnos() {
	}
	


	public Turnos(String tur_ini, String tur_fin, Dias dias) {
		super();
		this.tur_ini = tur_ini;
		this.tur_fin = tur_fin;
		this.dias = dias;
	}
	


	public Turnos(String tur_ini, String tur_fin, String tur_fecha, Dias dias) {
		super();
		this.tur_ini = tur_ini;
		this.tur_fin = tur_fin;
		this.tur_fecha = tur_fecha;
		this.dias = dias;
	}

	public Turnos(Integer tur_cod, String tur_ini, String tur_fin, String tur_fecha, Dias dias) {
		super();
		this.tur_cod = tur_cod;
		this.tur_ini = tur_ini;
		this.tur_fin = tur_fin;
		this.tur_fecha = tur_fecha;
		this.dias = dias;
	}



	public Integer getTur_cod() {
		return tur_cod;
	}

	public void setTur_cod(Integer id) {
		this.tur_cod = id;
	}

	

	public String getTur_ini() {
		return tur_ini;
	}



	public void setTur_ini(String tur_ini) {
		this.tur_ini = tur_ini;
	}



	public String getTur_fin() {
		return tur_fin;
	}



	public void setTur_fin(String tur_fin) {
		this.tur_fin = tur_fin;
	}

	
	

	public String getTur_fecha() {
		return tur_fecha;
	}



	public void setTur_fecha(String tur_fecha) {
		this.tur_fecha = tur_fecha;
	}



	public Dias getDias() {
		return dias;
	}


	public void setDias(Dias dias) {
		this.dias = dias;
	}

	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((dias == null) ? 0 : dias.hashCode());
		result = prime * result + ((tur_cod == null) ? 0 : tur_cod.hashCode());
		result = prime * result + ((tur_fecha == null) ? 0 : tur_fecha.hashCode());
		result = prime * result + ((tur_fin == null) ? 0 : tur_fin.hashCode());
		result = prime * result + ((tur_ini == null) ? 0 : tur_ini.hashCode());
		return result;
	}



	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Turnos other = (Turnos) obj;
		if (dias == null) {
			if (other.dias != null)
				return false;
		} else if (!dias.equals(other.dias))
			return false;
		if (tur_cod == null) {
			if (other.tur_cod != null)
				return false;
		} else if (!tur_cod.equals(other.tur_cod))
			return false;
		if (tur_fecha == null) {
			if (other.tur_fecha != null)
				return false;
		} else if (!tur_fecha.equals(other.tur_fecha))
			return false;
		if (tur_fin == null) {
			if (other.tur_fin != null)
				return false;
		} else if (!tur_fin.equals(other.tur_fin))
			return false;
		if (tur_ini == null) {
			if (other.tur_ini != null)
				return false;
		} else if (!tur_ini.equals(other.tur_ini))
			return false;
		return true;
	}



	@Override
	public String toString() {
		return "Turnos [tur_cod=" + tur_cod + ", tur_ini=" + tur_ini + ", tur_fin=" + tur_fin + ", tur_fecha=" + tur_fecha
				+ ", dias=" + dias + "]";
	}


}
	
	