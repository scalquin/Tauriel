package com.ejemplo.dbsrf.Models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="camara")
public class Camara implements Serializable{
	
private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="cam_cod")
	private Integer cam_cod;
	
	@Column(name="cam_iden")
	private String cam_iden;
	
	@Column(name="cam_zona")
	private String cam_zona;

	public Camara() {
	}
	
	

	public Camara(Integer cam_cod) {
		super();
		this.cam_cod = cam_cod;
	}



	public Camara(Integer cam_cod, String cam_iden, String cam_zona) {
		super();
		this.cam_cod = cam_cod;
		this.cam_iden = cam_iden;
		this.cam_zona = cam_zona;
	}



	public Integer getCam_cod() {
		return cam_cod;
	}



	public void setCam_cod(Integer cam_cod) {
		this.cam_cod = cam_cod;
	}



	public String getCam_iden() {
		return cam_iden;
	}

	public void setCam_iden(String cam_iden) {
		this.cam_iden = cam_iden;
	}

	public String getCam_zona() {
		return cam_zona;
	}

	public void setCam_zona(String cam_zona) {
		this.cam_zona = cam_zona;
	}
	
}
