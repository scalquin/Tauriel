package com.ejemplo.dbsrf.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ejemplo.dbsrf.Models.Roles;

public interface RolesDao extends JpaRepository<Roles, Long>{
	
}
