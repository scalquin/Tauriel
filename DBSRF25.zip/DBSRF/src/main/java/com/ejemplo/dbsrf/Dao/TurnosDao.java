package com.ejemplo.dbsrf.Dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ejemplo.dbsrf.Models.Turnos;

public interface TurnosDao extends JpaRepository<Turnos, Integer>{
	
} 
