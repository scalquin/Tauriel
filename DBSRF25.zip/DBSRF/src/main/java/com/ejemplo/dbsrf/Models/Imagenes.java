package com.ejemplo.dbsrf.Models;

import java.io.Serializable;
import java.util.Arrays;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.sun.istack.Nullable;

@Entity
@Table(name="imagenes")
public class Imagenes implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ima_cod")
	private Integer ima_cod;
	
	@Column(name="ima_img")
	@Nullable
	@Basic(optional=true, fetch=FetchType.EAGER)
	private String ima_img;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name= "usu_cod")
	@Nullable
	private Usuarios usuarios;

	public Imagenes() {}
	
	
	public Imagenes(Integer ima_cod, String ima_img ,Usuarios usuarios) {
		this.ima_cod = ima_cod;
		this.ima_img=ima_img;
		this.usuarios = usuarios;
	}

	public Integer getIma_cod() {
		return ima_cod;
	}

	public void setIma_cod(Integer ima_cod) {
		this.ima_cod = ima_cod;
	}

	public String getIma_img() {
		return ima_img;
	}

	public void setIma_img(String data) {
		this.ima_img = data;
	}

	public Usuarios getUsuarios() {
		return usuarios;
	}

	public void setUsuarios(Usuarios usuarios) {
		this.usuarios = usuarios;
	}
	
	
}
