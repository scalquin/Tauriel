package com.ejemplo.dbsrf.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ejemplo.dbsrf.Models.alerts;

public interface alertaRepo extends JpaRepository<alerts, Integer>{

}
