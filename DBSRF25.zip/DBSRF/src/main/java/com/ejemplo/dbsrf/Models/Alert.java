package com.ejemplo.dbsrf.Models;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


import com.sun.istack.Nullable;

@Entity
@Table(name="alert")
public class Alert implements Serializable{

private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ale_cod")
	private Integer ale_cod;
	
	@Column(name="ale_img")
	@Nullable
	@Basic(optional=true, fetch=FetchType.EAGER)
	private String ale_img;

	public Alert() {
	}

	public Alert(Integer ale_cod, String ale_img) {
		super();
		this.ale_cod = ale_cod;
		this.ale_img = ale_img;
	}

	public Integer getAle_cod() {
		return ale_cod;
	}

	public void setAle_cod(Integer ale_cod) {
		this.ale_cod = ale_cod;
	}

	public String getAle_img() {
		return ale_img;
	}

	public void setAle_img(String data) {
		this.ale_img = data;
	}
}
