package com.ejemplo.dbsrf.Models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.sun.istack.Nullable;

@Entity
@Table(name="Bitacora")
public class Bitacora implements Serializable{

private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="bit_cod")
	private Integer bit_cod;
	
	@Column(name="bit_estado")
	private boolean bit_estado;
	
	@Column(name="bit_fechor")
	private String bit_fechor;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name= "cam_cod")
	@Nullable
	private Camara camara;


	public Bitacora() {
	}


	public Bitacora(Integer bit_cod, boolean bit_estado, String bit_fechor, Camara camara) {
		super();
		this.bit_cod = bit_cod;
		this.bit_estado = bit_estado;
		this.bit_fechor = bit_fechor;
		this.camara = camara;
	}


	public Integer getBit_cod() {
		return bit_cod;
	}


	public void setBit_cod(Integer bit_cod) {
		this.bit_cod = bit_cod;
	}


	public boolean isBit_estado() {
		return bit_estado;
	}


	public void setBit_estado(boolean bit_estado) {
		this.bit_estado = bit_estado;
	}


	public String getBit_fechor() {
		return bit_fechor;
	}


	public void setBit_fechor(String bit_fechor) {
		this.bit_fechor = bit_fechor;
	}
	public Camara getCamara() {
		return camara;
	}

	public void setCamara(Camara camara) {
		this.camara = camara;
	}


	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((bit_cod == null) ? 0 : bit_cod.hashCode());
		result = prime * result + (bit_estado ? 1231 : 1237);
		result = prime * result + ((bit_fechor == null) ? 0 : bit_fechor.hashCode());
		result = prime * result + ((camara == null) ? 0 : camara.hashCode());
		return result;
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Bitacora other = (Bitacora) obj;
		if (bit_cod == null) {
			if (other.bit_cod != null)
				return false;
		} else if (!bit_cod.equals(other.bit_cod))
			return false;
		if (bit_estado != other.bit_estado)
			return false;
		if (bit_fechor == null) {
			if (other.bit_fechor != null)
				return false;
		} else if (!bit_fechor.equals(other.bit_fechor))
			return false;
		if (camara == null) {
			if (other.camara != null)
				return false;
		} else if (!camara.equals(other.camara))
			return false;
		return true;
	}


	@Override
	public String toString() {
		return "Bitacora [bit_cod=" + bit_cod + ", bit_estado=" + bit_estado + ", bit_fechor=" + bit_fechor
				+ ", camara=" + camara + "]";
	}
	
}
