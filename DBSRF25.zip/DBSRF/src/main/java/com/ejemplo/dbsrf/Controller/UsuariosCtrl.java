package com.ejemplo.dbsrf.Controller;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.imageio.ImageIO;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.validation.constraints.AssertTrue;

import org.apache.tomcat.util.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.scheduling.annotation.Async;
import org.springframework.ui.Model;
import org.springframework.util.Assert;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.async.AsyncWebRequest;

import com.ejemplo.dbsrf.Dao.ImagenesDao;
import com.ejemplo.dbsrf.Dao.UsuariosDao;
import com.ejemplo.dbsrf.Models.Alert;
import com.ejemplo.dbsrf.Models.Imagenes;
import com.ejemplo.dbsrf.Models.Roles;
import com.ejemplo.dbsrf.Models.Turnos;
import com.ejemplo.dbsrf.Models.Usuario;
import com.ejemplo.dbsrf.Models.Usuarios;
import com.ejemplo.dbsrf.Service.UsersService;
import com.ejemplo.dbsrf.Service.UsuariosService;
import com.google.gson.Gson;

@RestController
@RequestMapping(path = "/log")
@CrossOrigin(origins = { "http://192.168.43.168:4200","http://127.0.0.1:4200", "http://localhost:4200", "http://localhost:8082",
		"http://localhost:8080", "http://127.0.0.1:8080" })
public class UsuariosCtrl {
	@Autowired
	private UsersService user;
	@Autowired
	private UsuariosService users;
	@Autowired
	private UsuariosDao repo;
	@Autowired
	private ImagenesDao repo2;

	Base64 base64 = new Base64();

	Gson gson = new Gson();

	@RequestMapping(method = RequestMethod.POST, produces = MediaType.ALL_VALUE, consumes = MediaType.ALL_VALUE, path = "/login")
	@ResponseBody
	public String login(@RequestBody String data) {

		String[] a = data.split(",");
		System.out.println(a[0].substring(8).toString());
		System.out.println(user.getR(a[0].substring(9, a[0].length() - 1).toString()));
		if (user.getR(a[0].substring(9, a[0].length() - 1).toString())) {
			System.out.println("Hola");
			Usuario u = user.get(a[0].substring(9, a[0].length() - 1).toString());
			Usuarios us = users.get(u.getId());
			String cod2 = new String(base64.decode(u.getPassword().getBytes()));
			System.out.println(cod2);
			if (a[1].substring(8, a[1].length() - 2).toString().equals(cod2)) {
				// return us.getNombre().toString();
				// refreshUserData();
				System.out.println("regreso");
				return us.getRoles().getRol_nom();
			} else {
				return "null";
			}
		}
		return "null";
	}

	@RequestMapping(method = RequestMethod.GET, path = "/getusers")
	public List<Usuarios> getAll() {
		return users.getAll();
	}

	@GetMapping("/logout")
	public String logout() {
		System.out.println("Hola mundo");
		return "/getturnos";
	}

	@RequestMapping(method = RequestMethod.POST, path = "/addUser")
	@ResponseBody
	public String addUser(@RequestBody String User) {
		String[] data = User.split("|", 2);
		System.out.println(data[1]);
		Usuarios t = gson.fromJson(data[1].replace("|", ""), Usuarios.class);
		int a = Integer.parseInt(data[0]);
		Roles r = new Roles(a);
		t.setRoles(r);
		if (a == 1) {
			String cod = new String(base64.encode("Hola.123".getBytes()));
			t.setUsu_pass(cod);
		} else {
			t.setUsu_pass(null);
		}
		repo.save(t);

		return t.getUsu_cod().toString();
	}

	@RequestMapping(method = RequestMethod.POST, path = "/userse")
	@ResponseBody
	public String editUsers(@RequestBody String user) {
		String[] data = user.split("|", 3);
		Usuarios t = gson.fromJson(data[2].replace("|", ""), Usuarios.class);
		int a = Integer.parseInt(data[0]);
		Roles r = new Roles(Integer.parseInt(data[0]));
		t.setRoles(r);
		users.put(t, a);
		return "ok";
	}

	@RequestMapping(method = RequestMethod.POST, produces = MediaType.ALL_VALUE, consumes = MediaType.ALL_VALUE, path = "/usersd")
	@ResponseBody
	public void delete(@RequestBody String id) {
		// System.out.println(id);
		users.delete(Integer.parseInt(id));
	}

}