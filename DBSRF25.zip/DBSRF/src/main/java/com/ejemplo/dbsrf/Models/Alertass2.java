package com.ejemplo.dbsrf.Models;

import java.io.Serializable;

import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.sun.istack.Nullable;

@Entity
@Table(name="alert")
public class Alertass2 implements Serializable{

private static final long serialVersionUID = 1L;
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ale_cod")
	private Integer ale_cod;
	
	@Column(name="ale_fechor")
	private String ale_fechor;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name= "cam_cod")
	@Nullable
	private Camara camara;
	
	@Column(name="ale_img")
	@Nullable
	@Basic(optional=true, fetch=FetchType.EAGER)
	private String ale_img;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name= "usu_cod")
	@Nullable
	private Usuarios usuarios;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name= "tip_cod")
	@Nullable
	private TipoAlerta tipoAlerta;

	
	public Alertass2() {
	}


	public Alertass2(Integer ale_cod, String ale_fechor, Camara camara, String ale_img, Usuarios usuarios,
			TipoAlerta tipoAlerta) {
		this.ale_cod = ale_cod;
		this.ale_fechor = ale_fechor;
		this.camara = camara;
		this.ale_img = ale_img;
		this.usuarios = usuarios;
		this.tipoAlerta = tipoAlerta;
	}


	public Integer getAle_cod() {
		return ale_cod;
	}


	public void setAle_cod(Integer ale_cod) {
		this.ale_cod = ale_cod;
	}


	public String getAle_fechor() {
		return ale_fechor;
	}


	public void setAle_fechor(String ale_fechor) {
		this.ale_fechor = ale_fechor;
	}


	public Camara getCamara() {
		return camara;
	}


	public void setCamara(Camara camara) {
		this.camara = camara;
	}


	public String getAle_img() {
		return ale_img;
	}


	public void setAle_img(String data) {
		this.ale_img = data;
	}


	public Usuarios getUsuarios() {
		return usuarios;
	}


	public void setUsuarios(Usuarios usuarios) {
		this.usuarios = usuarios;
	}


	public TipoAlerta getTipoAlerta() {
		return tipoAlerta;
	}


	public void setTipoAlerta(TipoAlerta tipoAlerta) {
		this.tipoAlerta = tipoAlerta;
	}
	
	
}
