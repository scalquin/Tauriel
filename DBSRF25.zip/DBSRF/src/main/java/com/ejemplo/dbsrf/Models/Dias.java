package com.ejemplo.dbsrf.Models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "dias")
public class Dias implements Serializable{
	
	private static final long serialVersionUID = 1L;

	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	private int dia_cod;
	
	@Column(name="dia_nom")
	private String dia_nom;
	
	public Dias() {}

	public Dias(int dia_cod) {
		this.dia_cod=dia_cod;
	}
	
	public Dias(int dia_cod, String dia_nom) {
		this.dia_cod = dia_cod;
		this.dia_nom = dia_nom;
	}

	public long getDia_cod() {
		return dia_cod;
	}

	public void setDia_cod(int dia_cod) {
		this.dia_cod = dia_cod;
	}

	public String getDia_nom() {
		return dia_nom;
	}

	public void setDia_nom(String dia_nom) {
		this.dia_nom = dia_nom;
	}

}
