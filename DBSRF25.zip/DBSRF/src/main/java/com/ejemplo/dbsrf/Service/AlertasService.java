package com.ejemplo.dbsrf.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ejemplo.dbsrf.Models.Alert;
import com.ejemplo.dbsrf.Models.Alertass2;
import com.ejemplo.dbsrf.Models.alertas;
import com.ejemplo.dbsrf.Models.alerts;
import com.ejemplo.dbsrf.Repo.AlertDao;
import com.ejemplo.dbsrf.Repo.AlertasDao2;
import com.ejemplo.dbsrf.Dao.AlertasDao;
import com.ejemplo.dbsrf.Repo.alertaRepo;

@Service
public class AlertasService implements IAlertasService{

	@Autowired
	private AlertasDao alertDao;
	@Autowired
	private alertaRepo aleRepo;
	@Autowired
	private AlertDao ale;
	@Autowired
	private AlertasDao2 aleD;
	//Definir metodo para listar las alertas sin imagenes
	@Override
	public List<alerts> getAll() {
		return aleRepo.findAll();
	}
	//Definir metodo para buscar la imagen necesaria
	@Override
	public Alert getAlert(int id) {
		return alertDao.findById(id);
	}
	//Definir metodo para listar codigo y fecha de la alerta
	@Override
	public List<alertas> getCount() {
		return aleD.findAll();
	}
	//Definir metodo para ingresar alerta a la base de datos
	@Override
	public void post(Alertass2 a) {
		ale.save(a);
	}
	//Definir metodo para actualizar los datos en la base de datos
	@Override
	public void put(Alertass2 a, int id) {
		ale.findById(id).ifPresent((x)->{
			a.setAle_cod(id);
			ale.save(a);
		});
	}
	//Definir metodo para eliminar un registro
	@Override
	public void delete(Integer id) {
		ale.deleteById(id);	
	}
}
