package com.ejemplo.dbsrf.Models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="TipoAlerta")
public class TipoAlerta implements Serializable{
	
private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="tip_cod")
	private Integer tip_cod;
	
	@Column(name="tipo_desc")
	private String tipo_desc;

	public TipoAlerta() {
	}

	public TipoAlerta(Integer tip_cod, String tipo_desc) {
		super();
		this.tip_cod = tip_cod;
		this.tipo_desc = tipo_desc;
	}

	public TipoAlerta(int i) {
		this.tip_cod=i;
	}

	public Integer getTip_cod() {
		return tip_cod;
	}

	public void setTip_cod(Integer tip_cod) {
		this.tip_cod = tip_cod;
	}

	public String getTipo_desc() {
		return tipo_desc;
	}

	public void setTipo_desc(String tipo_desc) {
		this.tipo_desc = tipo_desc;
	}

}
