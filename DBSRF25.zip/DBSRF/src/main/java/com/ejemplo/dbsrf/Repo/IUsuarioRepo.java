package com.ejemplo.dbsrf.Repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.query.Param;

import com.ejemplo.dbsrf.Models.Usuario;
import com.ejemplo.dbsrf.Models.Usuarios;

public interface IUsuarioRepo extends JpaRepository<Usuario, Integer>{
	Usuario findByNombre(String nombre);
	boolean existsByNombre(String nombre);
}

