package com.ejemplo.dbsrf.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ejemplo.dbsrf.Dao.DiasDao;
import com.ejemplo.dbsrf.Models.Dias;

@Service
public class DiasServiceImpl implements IDiasService{
	@Autowired
	private DiasDao diasDao;
	
	@Override
	public Dias get(Integer id) {
		return diasDao.findById(id).get();
	}
	
	@Override
	public List<Dias> getAll(){
		return (List<Dias>) diasDao.findAll();
	}

	public Iterable<Dias> list() {
		
		return diasDao.findAll();
	}
	
}
