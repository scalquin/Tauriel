package com.ejemplo.dbsrf.Controller;

import java.util.List;

import org.apache.juli.logging.Log;
import org.apache.juli.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ejemplo.dbsrf.Models.Dias;
import com.ejemplo.dbsrf.Service.DiasServiceImpl;

@RestController
@RequestMapping(path="/dias")
@CrossOrigin(origins = {"http://192.168.43.168:4200","http://127.0.0.1:4200","http://localhost:4200" ,"http://localhost:8082", "http://localhost:8080","http://127.0.0.1:8080"})
public class DiasCtrl {
	
	private static Log log = LogFactory.getLog(DiasCtrl.class);
	
	@Autowired
	private DiasServiceImpl diasService;

	@RequestMapping(method=RequestMethod.GET,
			path="/getdias"
			)
	public List<Dias> getAll(){
		return diasService.getAll();
	};
	
	@GetMapping("/list")
	public @ResponseBody List<Dias> getDias(){
		List<Dias> dias = null;
		try {
			dias = diasService.getAll();
		}catch(Exception exception){
			log.error(exception);
		}
		return dias;
	}
	

	
}
