package com.ejemplo.dbsrf.Controller;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

@Service
public class ConexionCtrl {
	//Atributos
    private String usuario;
    private String password;
    private String url;
    //objeto tipo conexion
    Connection con=null;

    public ConexionCtrl() {
        this.usuario="postgres";
        this.password="Samael";
        this.url="jdbc:postgresql://192.168.0.3:5432/srf3";

    }
    //conectar
    @Bean
    public void conectar(){
        try {
            //llamar al driver
            Class.forName("org.postgresql.Driver");
            // cadena de conexion
            con=DriverManager.getConnection(url,usuario,password);
        } catch (SQLException | ClassNotFoundException ex) {
            Logger.getLogger(ConexionCtrl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    //desconectar
    public void cerrar(){
        con=null;
    }
    //estado
    public Connection estado(){
        return con;
    }
}
