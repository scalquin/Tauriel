package com.ejemplo.dbsrf.Service;

import java.util.List;

import com.ejemplo.dbsrf.Models.Imagenes;
import com.ejemplo.dbsrf.Models.Usuarios;

public interface IImagenesService {
	public Imagenes get(int id);
	public List<Imagenes> getAll();
	public void post(Imagenes i);
	public List<Imagenes> gets(Usuarios us);
}
