package com.ejemplo.dbsrf.Models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import com.sun.istack.Nullable;

@Entity
@Table(name = "zonaturnos")
public class ZonaTurnos implements Serializable {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "zt_cod")
	private Integer zt_cod;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "tur_cod")
	@Nullable
	private Turnos turnos;

	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "zon_cod")
	@Nullable
	private Zona zona;

	public ZonaTurnos() {
	}
	
	public ZonaTurnos(Turnos turnos, Zona zona) {
		super();
		this.turnos = turnos;
		this.zona = zona;
	}
	
	public ZonaTurnos(Integer zt_cod,Turnos turnos, Zona zona) {
		super();
		this.zt_cod=zt_cod;
		this.turnos = turnos;
		this.zona = zona;
	}
	
	

	public Integer getZt_cod() {
		return zt_cod;
	}

	public void setZt_cod(Integer zt_cod) {
		this.zt_cod = zt_cod;
	}

	public Turnos getTurnos() {
		return turnos;
	}

	public void setTurnos(Turnos turnos) {
		this.turnos = turnos;
	}

	public Zona getZona() {
		return zona;
	}

	public void setZona(Zona zona) {
		this.zona = zona;
	}
	
}
