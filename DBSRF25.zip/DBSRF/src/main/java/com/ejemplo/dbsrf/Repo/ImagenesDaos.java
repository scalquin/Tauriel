package com.ejemplo.dbsrf.Repo;


import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.ejemplo.dbsrf.Models.Imagenes;

public interface ImagenesDaos extends CrudRepository<Imagenes, Integer>{
	
}
