package com.ejemplo.dbsrf.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ejemplo.dbsrf.Models.Turnos;

public interface TurnosRepo extends JpaRepository<Turnos, Integer>{

}
