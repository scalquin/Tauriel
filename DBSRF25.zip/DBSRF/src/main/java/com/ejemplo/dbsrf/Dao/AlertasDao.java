package com.ejemplo.dbsrf.Dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ejemplo.dbsrf.Models.Alert;

public interface AlertasDao extends JpaRepository<Alert, Integer>{
	Alert findById(int id);
}
