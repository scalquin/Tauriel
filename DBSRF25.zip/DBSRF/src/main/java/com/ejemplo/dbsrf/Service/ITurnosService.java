package com.ejemplo.dbsrf.Service;

import java.util.List;

import com.ejemplo.dbsrf.Models.Turnos;

public interface ITurnosService {
	public Turnos get(int id);
	public List<Turnos> getAll();
	public void post(Turnos t);
	public void put(Turnos t,int id);
	public void delete(Integer id);
	
}
