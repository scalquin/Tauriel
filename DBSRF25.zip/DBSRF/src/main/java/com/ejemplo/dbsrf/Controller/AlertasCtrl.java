package com.ejemplo.dbsrf.Controller;

import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Base64;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.imageio.ImageIO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;


import com.ejemplo.dbsrf.Models.Alert;
import com.ejemplo.dbsrf.Models.Alertass;
import com.ejemplo.dbsrf.Models.Alertass2;
import com.ejemplo.dbsrf.Models.Camara;
import com.ejemplo.dbsrf.Models.TipoAlerta;
import com.ejemplo.dbsrf.Models.Usuario;
import com.ejemplo.dbsrf.Models.Usuarios;
import com.ejemplo.dbsrf.Models.alerts;
import com.ejemplo.dbsrf.Repo.AlertDao;
import com.ejemplo.dbsrf.Repo.AlertasDao2;
import com.ejemplo.dbsrf.Service.AlertasService;
import com.google.gson.Gson;

@RestController
@RequestMapping(path = "/alerts")
@CrossOrigin(origins = { "http://127.0.0.1:4200", "http://localhost:4200", "http://localhost:8082",
		"http://localhost:8080", "http://127.0.0.1:8080","http://192.168.43.168:4200" })
public class AlertasCtrl {
	public int count;
	private int a;
	Connection con = null;
	@Autowired
	private AlertasService alertService;
	@Autowired
	private AlertasDao2 alertDao;
	@Autowired
	private AlertDao alerDao;
	@Autowired
	private AlertasDao2 aleD;
	@Autowired
	private ConexionCtrl cont;

	String jsont;
	Gson gson = new Gson();
	ByteArrayOutputStream bos = new ByteArrayOutputStream();

	@RequestMapping(method = RequestMethod.GET, path = "/Ales")
	public String alerta() throws InterruptedException, SQLException, ClassNotFoundException {
		cont = new ConexionCtrl();
		ResultSet res;
		String alerta="alert";
		while (a<=this.count) {
			a = aleD.findAll().size();
			System.out.println("Hola");
			Thread.sleep(3000);
		}
		try {
			// conectar al servidor
			cont.conectar();
			Class.forName("org.postgresql.Driver");
			con = DriverManager.getConnection("jdbc:postgresql://192.168.0.3/:5432/srf3", "postgres", "Samael");
			Statement stmt = con.createStatement();
			String sql = "select tip_cod from alert order by ale_cod desc";
			res = stmt.executeQuery(sql);
			res.next();
			System.out.println(res.getString(1));
			if(Integer.parseInt(res.getString(1))==2) {
			alerta="nothing";
			}
		} catch (SQLException ex) {
			Logger.getLogger(AlertasCtrl.class.getName()).log(Level.SEVERE, null, ex);
		} finally {
			// cerrar conexion
			cont.cerrar();
		}
		this.count = a;
		System.out.println(alerta);
		return alerta;
		
		
	}

	@RequestMapping(method = RequestMethod.GET, path = "/getAll")
	public List<alerts> getAlertas() {
		return alertService.getAll();
	}

	@RequestMapping(method = RequestMethod.GET, path = "/getOne/{id}")
	public Alertass getOne(@PathVariable(value = "id") int id) {
		Alert al = alertService.getAlert(id);
		Alertass ale = new Alertass();

		ale.setAle_img(al.getAle_img());
		return ale;
	}

	@RequestMapping(method = RequestMethod.POST, path = "/AddAlerta")
	@ResponseBody
	public String AddAlerta(@RequestBody String datos) throws IOException {
		// separar el string en id camara, id usuario, id tipo alerta y objeto
		String[] dat = datos.split("=", 2);
		String[] data = dat[1].split("%2C", 5);
		System.out.println(data[0]);
		System.out.println(data[1]);
		System.out.println(data[2]);
		System.out.println(data[3].replace("%2F", "/").replace("-", "").replace("%3A", ":"));
		System.out.println(data[4]);
		/*
		 * Alertass2 ale=new Alertass2(); Camara c=new
		 * Camara(Integer.parseInt(data[1])); Usuarios u=new
		 * Usuarios(Integer.parseInt(data[0])); TipoAlerta tp=new
		 * TipoAlerta(Integer.parseInt(data[2])); //Alertass2
		 * ale=gson.fromJson(data[3].replace("%2F",
		 * " ").replace("%3A",":"),Alertass2.class); ale.setAle_img(data[4]);
		 * ale.setCamara(c); ale.setUsuarios(u); ale.setAle_fechor(data[3]);
		 * ale.setTipoAlerta(tp);
		 */

		try {
			// conectar al servidor
			cont.conectar();
			// crear un objeto capaz de soportar una consulta
			PreparedStatement sql = cont.estado()
					.prepareStatement("insert into alert(cam_cod,ale_img,ale_fechor,usu_cod,tip_cod) Values('"
							+ Integer.parseInt(data[1]) + "','" + data[4].replace("%2F", "/") + "','"
							+ data[3].replace("%2F", "/").replace("%3A", ":") + "','" + data[0] + "','" + data[2]
							+ "')");
			sql.execute();
		} catch (SQLException ex) {
			Logger.getLogger(AlertasCtrl.class.getName()).log(Level.SEVERE, null, ex);
		} finally {
			// cerrar conexion
			cont.cerrar();
		}

		return "null";
	}

}
