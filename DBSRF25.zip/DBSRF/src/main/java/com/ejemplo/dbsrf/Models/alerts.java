package com.ejemplo.dbsrf.Models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.sun.istack.Nullable;

@Entity
@Table(name="alert")
public class alerts implements Serializable{

private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="ale_cod")
	private Integer ale_cod;
	
	@Column(name="ale_fechor")
	private String ale_fechor;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name= "cam_cod")
	@Nullable
	private Camara camara;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name= "usu_cod")
	@Nullable
	private Usuarios usuarios;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name= "tip_cod")
	@Nullable
	private TipoAlerta tipoAlerta;

	public alerts() {
	}

	public alerts(Integer ale_cod, Camara camara, Usuarios usuarios, TipoAlerta tipoAlerta,String ale_fechor) {
		super();
		this.ale_cod = ale_cod;
		this.camara = camara;
		this.ale_fechor=ale_fechor;
		this.usuarios = usuarios;
		this.tipoAlerta = tipoAlerta;
	}

	public Integer getAle_cod() {
		return ale_cod;
	}

	public void setAle_cod(Integer ale_cod) {
		this.ale_cod = ale_cod;
	}

	public Camara getCamara() {
		return camara;
	}

	public void setCamara(Camara camara) {
		this.camara = camara;
	}

	public String getAle_fechor() {
		return ale_fechor;
	}

	public void setAle_fechor(String ale_fechor) {
		this.ale_fechor = ale_fechor;
	}

	public Usuarios getUsuarios() {
		return usuarios;
	}

	public void setUsuarios(Usuarios usuarios) {
		this.usuarios = usuarios;
	}

	public TipoAlerta getTipoAlerta() {
		return tipoAlerta;
	}

	public void setTipoAlerta(TipoAlerta tipoAlerta) {
		this.tipoAlerta = tipoAlerta;
	}

}
