package com.ejemplo.dbsrf.Service;

import java.net.URI;
import java.net.URISyntaxException;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.util.Assert;
import org.springframework.web.client.RestTemplate;


public class RestRequests {
	 public void getGreeting() throws URISyntaxException {
		 RestTemplate restTemplate = new RestTemplate();
	     
		    final String baseUrl = "http://localhost:8101/blank";
		    URI uri = new URI(baseUrl);
		 
		    ResponseEntity<String> result = restTemplate.getForEntity(uri, String.class);
		   
		   }
}
