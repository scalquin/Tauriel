package com.ejemplo.dbsrf.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ejemplo.dbsrf.Dao.ImagenesDao;
import com.ejemplo.dbsrf.Models.Imagenes;
import com.ejemplo.dbsrf.Models.Usuarios;

@Service
public class ImagenesService implements IImagenesService {

		@Autowired
		private ImagenesDao imgdao;

		@Override
		public Imagenes get(int id) {
			return imgdao.findById(id).get();
		}

		@Override
		public List<Imagenes> getAll() {
			return imgdao.findAll();
		}

		@Override
		public void post(Imagenes i) {
			imgdao.save(i);
		}
		@Override
		public List<Imagenes> gets(Usuarios us) {
			return imgdao.findByUsuarios(us);
		}
}
