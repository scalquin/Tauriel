package com.ejemplo.dbsrf.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ejemplo.dbsrf.Dao.UsuariosDao;
import com.ejemplo.dbsrf.Models.Usuario;
import com.ejemplo.dbsrf.Models.Usuarios;
import com.ejemplo.dbsrf.Repo.IUsuarioRepo;

@Service
public class UsersService implements IUsersService{
	
	@Autowired
	private IUsuarioRepo usudao;
	
	

	@Override
	public Usuario get(String usu_rut) {
		
		return usudao.findByNombre(usu_rut);
	}
	@Override
	public boolean getR(String usu_rut) {
		
		return usudao.existsByNombre(usu_rut);
	}
	
}
