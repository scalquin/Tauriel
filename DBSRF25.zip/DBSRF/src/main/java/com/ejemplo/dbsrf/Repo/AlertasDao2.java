package com.ejemplo.dbsrf.Repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ejemplo.dbsrf.Models.alertas;


public interface AlertasDao2 extends JpaRepository<alertas, Integer>{
	
}
