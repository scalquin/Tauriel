package com.ejemplo.dbsrf.Models;

public class Señal {
	
	private long id;
	
	private String content;
	   
	   
	public Señal() {
	}


	public Señal(long id, String content) {
		this.id = id;
		this.content = content;
	}


	public long getId() {
		return id;
	}


	public void setId(long id) {
		this.id = id;
	}


	public String getContent() {
		return content;
	}


	public void setContent(String content) {
		this.content = content;
	}
	  
	   
}
