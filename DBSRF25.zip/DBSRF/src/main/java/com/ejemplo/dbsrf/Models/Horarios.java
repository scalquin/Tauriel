package com.ejemplo.dbsrf.Models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.sun.istack.Nullable;

@Entity
@Table(name="horarios")
public class Horarios implements Serializable{

private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="hor_cod")
	private Integer hor_cod;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name= "usu_cod")
	@Nullable
	private Usuarios usuarios;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name= "tur_cod")
	@Nullable
	private Turnos turnos;

	public Horarios() {
	}

	public Horarios(Integer hor_cod, Usuarios usuarios, Turnos turnos) {
		super();
		this.hor_cod = hor_cod;
		this.usuarios = usuarios;
		this.turnos = turnos;
	}

	public Integer getHor_cod() {
		return hor_cod;
	}

	public void setHor_cod(Integer hor_cod) {
		this.hor_cod = hor_cod;
	}

	public Usuarios getUsuarios() {
		return usuarios;
	}

	public void setUsuarios(Usuarios usuarios) {
		this.usuarios = usuarios;
	}

	public Turnos getTurnos() {
		return turnos;
	}

	public void setTurnos(Turnos turnos) {
		this.turnos = turnos;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((hor_cod == null) ? 0 : hor_cod.hashCode());
		result = prime * result + ((turnos == null) ? 0 : turnos.hashCode());
		result = prime * result + ((usuarios == null) ? 0 : usuarios.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Horarios other = (Horarios) obj;
		if (hor_cod == null) {
			if (other.hor_cod != null)
				return false;
		} else if (!hor_cod.equals(other.hor_cod))
			return false;
		if (turnos == null) {
			if (other.turnos != null)
				return false;
		} else if (!turnos.equals(other.turnos))
			return false;
		if (usuarios == null) {
			if (other.usuarios != null)
				return false;
		} else if (!usuarios.equals(other.usuarios))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Horarios [hor_cod=" + hor_cod + ", usuarios=" + usuarios + ", turnos=" + turnos + "]";
	}

	
}
