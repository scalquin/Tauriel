package com.ejemplo.dbsrf.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ejemplo.dbsrf.Dao.UsuariosDao;
import com.ejemplo.dbsrf.Models.Turnos;
import com.ejemplo.dbsrf.Models.Usuarios;

@Service
public class UsuariosService implements IUsuariosService{
	
	@Autowired
	private UsuariosDao usudao;
	
	@Override
	public Usuarios get(int id) {
		return usudao.findById(id).get();
	}
	@Override
	public List<Usuarios> getAll(){
		return (List<Usuarios>) usudao.findAll();
	}
	public void post(Usuarios u) {
		usudao.save(u);
	}
	public void put(Usuarios u,int id) {
		usudao.findById(id).ifPresent((x)->{
			u.setUsu_cod(id);
			usudao.save(u);
	});
	}
	public void delete(int id) {
		usudao.deleteById(id);
	}
	
}
