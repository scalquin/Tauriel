package com.ejemplo.dbsrf.Models;


public class Alertass {
	
	private Integer ale_cod;
	
	private String ale_img;

	public Alertass() {
	}
	
	public Alertass(Integer ale_cod) {
		this.ale_cod=ale_cod;
	}

	public Alertass(Integer ale_cod, String ale_img) {
		this.ale_cod = ale_cod;
		this.ale_img = ale_img;
	}

	public Integer getAle_cod() {
		return ale_cod;
	}

	public void setAle_cod(Integer ale_cod) {
		this.ale_cod = ale_cod;
	}

	public String getAle_img() {
		return ale_img;
	}

	public void setAle_img(String ale_img) {
		this.ale_img = ale_img;
	}	
}
