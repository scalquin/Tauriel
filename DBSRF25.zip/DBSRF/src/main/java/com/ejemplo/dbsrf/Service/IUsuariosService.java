package com.ejemplo.dbsrf.Service;

import java.util.List;

import com.ejemplo.dbsrf.Models.Usuarios;

public interface IUsuariosService {
	public Usuarios get(int id);
	public List<Usuarios> getAll();
	public void post(Usuarios u);
	public void put(Usuarios u, int id);
	public void delete(int id);
}
