package com.ejemplo.dbsrf.Service;

import com.ejemplo.dbsrf.Models.Usuario;

public interface IUsersService {
	public Usuario get(String usu_rut);
	public boolean getR(String usu_rut);
}
