package com.ejemplo.dbsrf.Models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import com.sun.istack.Nullable;

@Entity
@Table(name="usuarios")
public class Usuarios implements Serializable{
	
private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="usu_cod")
	private Integer usu_cod;
	
	@Column(name="usu_nom")
	private String nombre;
	
	@Column(name="usu_apep")
	private String usu_apep;
	
	@Column(name="usu_apem")
	private String usu_apem;
	
	@Column(name="usu_rut")
	private String usu_rut;
	
	@Column(name="usu_tel")
	private String usu_tel;
	
	@Column(name="usu_dir")
	private String usu_dir;
	
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name= "rol_cod")
	@Nullable
	private Roles roles;
	
	@Column(name="usu_pass")
	private String usu_pass;

	
	public Usuarios() {
	}
	

	public Usuarios(Integer usu_cod, String nombre, String usu_apep, String usu_apem, String usu_rut, String usu_tel,
			String usu_dir, Roles roles, String usu_pass) {
		super();
		this.usu_cod = usu_cod;
		this.nombre = nombre;
		this.usu_apep = usu_apep;
		this.usu_apem = usu_apem;
		this.usu_rut = usu_rut;
		this.usu_tel = usu_tel;
		this.usu_dir = usu_dir;
		this.roles = roles;
		this.usu_pass = usu_pass;
	}


	public Usuarios(int id) {
		this.usu_cod=id;
	}


	public Integer getUsu_cod() {
		return usu_cod;
	}

	public void setUsu_cod(Integer usu_cod) {
		this.usu_cod = usu_cod;
	}


	public String getNombre() {
		return nombre;
	}


	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public String getUsu_apep() {
		return usu_apep;
	}

	public void setUsu_apep(String usu_apep) {
		this.usu_apep = usu_apep;
	}

	public String getUsu_apem() {
		return usu_apem;
	}

	public void setUsu_apem(String usu_apem) {
		this.usu_apem = usu_apem;
	}

	public String getUsu_rut() {
		return usu_rut;
	}

	public void setUsu_rut(String usu_rut) {
		this.usu_rut = usu_rut;
	}

	public String getUsu_tel() {
		return usu_tel;
	}

	public void setUsu_tel(String usu_tel) {
		this.usu_tel = usu_tel;
	}

	public String getUsu_dir() {
		return usu_dir;
	}

	public void setUsu_dir(String usu_dir) {
		this.usu_dir = usu_dir;
	}

	public Roles getRoles() {
		return roles;
	}

	public void setRoles(Roles roles) {
		this.roles = roles;
	}

	public String getUsu_pass() {
		return usu_pass;
	}

	public void setUsu_pass(String usu_pass) {
		this.usu_pass = usu_pass;
	}


}
