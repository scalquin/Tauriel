package com.ejemplo.dbsrf.Models;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="zona")
public class Zona implements Serializable{

private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="zon_cod")
	private Integer zon_cod;
	
	@Column(name="zon_nom")
	private String zon_nom;

	public Zona() {
	}

	public Zona(Integer zon_cod, String zon_nom) {
		super();
		this.zon_cod = zon_cod;
		this.zon_nom = zon_nom;
	}

	public Integer getzon_cod() {
		return zon_cod;
	}

	public void setzon_cod(Integer zon_cod) {
		this.zon_cod = zon_cod;
	}

	public String getZon_nom() {
		return zon_nom;
	}

	public void setZon_nom(String zon_nom) {
		this.zon_nom = zon_nom;
	}	
}
