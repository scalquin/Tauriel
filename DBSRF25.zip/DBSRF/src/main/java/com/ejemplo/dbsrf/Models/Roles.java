package com.ejemplo.dbsrf.Models;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="RolesDao")
public class Roles implements Serializable{
	
private static final long serialVersionUID = 1L;
	
	@Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name="rol_cod")
	private Integer rol_cod;
	
	@Column(name="rol_nom")
	private String rol_nom;

	public Roles() {
	}
	public Roles(Integer rol_cod) {
		this.rol_cod=rol_cod;
	}

	public Roles(Integer rol_cod, String rol_nom) {
		super();
		this.rol_cod = rol_cod;
		this.rol_nom = rol_nom;
	}

	public Integer getRol_cod() {
		return rol_cod;
	}

	public void setRol_cod(Integer id) {
		this.rol_cod = id;
	}

	public String getRol_nom() {
		return rol_nom;
	}

	public void setRol_nom(String rol_nom) {
		this.rol_nom = rol_nom;
	}
	
	
}
