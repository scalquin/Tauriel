package com.ejemplo.dbsrf.Repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ejemplo.dbsrf.Models.Alertass2;

public interface AlertDao extends JpaRepository<Alertass2, Integer>{
	
}
