package com.ejemplo.dbsrf.Dao;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;

import com.ejemplo.dbsrf.Models.Imagenes;
import com.ejemplo.dbsrf.Models.Usuarios;

public interface ImagenesDao extends JpaRepository<Imagenes,Integer>{
	List<Imagenes> findByUsuarios(Usuarios us);
}
