package com.ejemplo.dbsrf.Controller;


import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.IOException;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Base64;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.imageio.ImageIO;
import javax.swing.text.html.FormSubmitEvent.MethodType;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.ejemplo.dbsrf.Models.Imagenes;
import com.ejemplo.dbsrf.Models.Imagenes2;
import com.ejemplo.dbsrf.Models.Usuarios;
import com.ejemplo.dbsrf.Service.ImagenesService;

@RestController
@RequestMapping(path = "/ima")
@CrossOrigin(origins = { "http://192.168.43.168:4200","http://localhost:8100", "http://localhost:8082","http://localhost:8080","http://127.0.0.1:8080","http://127.0.0.1:4200","http://localhost:4200" })
public class ImagenesCtrl {
	
	@Autowired
	private ImagenesService imaService;
	
	@RequestMapping(method=RequestMethod.GET,
			path="/list")
	@ResponseBody
	public List<Imagenes> enviar(){
		return imaService.getAll();
	}
	@RequestMapping(method=RequestMethod.GET,
			path="/getOne/{id}"
			)
	public Imagenes2 getOne(@PathVariable(value = "id") int id){
		Imagenes im= imaService.get(id);
		Usuarios u=new Usuarios(14);
		Imagenes2 ima=new Imagenes2();
		ima.setIma_cod(im.getIma_cod());
		ima.setIma_img(im.getIma_img());
		ima.setUsuarios(u);
		return ima;
	}
	@RequestMapping(method=RequestMethod.POST,
			path="/addIma")
	@ResponseBody
	public void Getsa(@RequestBody String datas) throws IOException {
		System.out.println(datas);
		String dato[]=datas.split("|",3);
		String id= (dato[0]+dato[1]);
		String img=dato[2].replace("data:image/jpeg;base64,","");
		System.out.println(dato[2]);
		ConexionCtrl con=new ConexionCtrl();
	      try {
	            //conectar al servidor
	            con.conectar();
	            //crear un objeto capaz de soportar una consulta
	            PreparedStatement sql = con.estado().prepareStatement("insert into imagenes(ima_img,usu_cod) Values('" +img+"','"+id+"')");
	            sql.execute();
	        } catch (SQLException ex) {
	            Logger.getLogger(ImagenesCtrl.class.getName()).log(Level.SEVERE, null, ex);
	        } finally {
	            //cerrar conexion
	            con.cerrar();
	        }
	}
	
}
