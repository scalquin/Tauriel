package com.ejemplo.dbsrf.Service;

import java.util.List;

import com.ejemplo.dbsrf.Models.Alert;
import com.ejemplo.dbsrf.Models.Alertass2;
import com.ejemplo.dbsrf.Models.Turnos;
import com.ejemplo.dbsrf.Models.alertas;
import com.ejemplo.dbsrf.Models.alerts;

public interface IAlertasService {
	public List<alerts> getAll();
	public List<alertas> getCount();
	public Alert getAlert(int id);
	public void post(Alertass2 a);
	public void put(Alertass2 a,int id);
	public void delete(Integer id);
}
